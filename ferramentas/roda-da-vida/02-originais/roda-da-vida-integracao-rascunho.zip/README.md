# Roda da Vida — integração preparada para APC 3.0

**Status: rascunho de integração, não publicado e não conectado ao banco.**

Destinatário autorizado: contato@manoelgoncalves.com.

Este pacote é uma sobreposição de arquivos ao projeto Next.js do APC, não é um site completo nem deve substituir sozinho a implantação existente. Reutiliza `assertExpectedDatabase`, `createSmtpMailer` e `consumeRateLimit`, cujas interfaces foram conferidas na fonte hospedada. Não contém credenciais ou cópia de avaliações.

## Comportamento preparado

- Endpoint POST `/diagnostico/roda-da-vida/envio` recebe as 70 respostas, identificação, data e 14 observações.
- Validação no servidor; as 14 médias são calculadas novamente, sem confiar em valores derivados do navegador.
- Gravação e inclusão da notificação em fila na mesma transação. Usa duas tabelas próprias: `rvp_assessments` e `rvp_notifications`.
- UUID e hash impedem a duplicação do mesmo envio e rejeitam a reutilização de um identificador com outros dados.
- Aviso por SMTP depois da gravação. Mensagem inclui identificação e número do registro, sem respostas pessoais.
- Em falha de SMTP, preserva a avaliação e mantém o aviso pendente. O despachante precisa ser acionado periodicamente por tarefa autenticada; essa configuração ainda não está implementada nem ativada.

## Pendências antes da ativação

1. Abrir a fonte num checkout completo do APC e executar typecheck/build/testes do projeto. Os testes incluídos cobrem apenas validação e cálculo.
2. Confirmar que o banco configurado como `u821131820_apc_homolog` existe, está acessível e é o destino escolhido para a Roda. A configuração foi localizada, mas nenhuma conexão SQL foi testada.
3. Integrar o formulário HTML ao novo endpoint: consentimento de envio, nome obrigatório ao concluir, UUID persistente por avaliação, estado de envio e confirmação apenas após a resposta do banco. O HTML publicado continua sem esse código.
4. Integrar consulta dos registros ao painel protegido, se desejada; não existe endpoint público de leitura neste pacote.
5. Implementar e ativar o despachante periódico autenticado de notificações. SMTP não garante entrega exatamente uma vez em caso de falha entre a aceitação da mensagem e a confirmação no banco.
6. Ativar `RVP_ENABLE_SUBMISSIONS=enabled`, preservando todas as variáveis existentes. Sem essa variável o endpoint devolve 503.
7. Fazer teste real no MySQL e envio de um aviso de teste ao destinatário autorizado. Nenhum e-mail foi enviado durante a preparação.

Nenhuma tabela APC existente é alterada pelo código. O esquema usa `CREATE TABLE IF NOT EXISTS`, somente para as duas tabelas RVP. A criação requer privilégios no banco e deve ocorrer em uma etapa de implantação autorizada.
