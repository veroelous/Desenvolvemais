import { NextResponse, after } from 'next/server';
import { validateSubmission } from '@/lib/roda/validate.mjs';
import { saveSubmission, notifyPending } from '@/lib/roda/storage';
import { consumeRateLimit } from '@/lib/auth/rate';
export const runtime='nodejs';
export async function POST(request:Request) {
  if(process.env.RVP_ENABLE_SUBMISSIONS!=='enabled') return NextResponse.json({error:'Envio ainda não ativado.'},{status:503});
  const expected=process.env.APP_URL;
  if(!expected || request.headers.get('origin')!==new URL(expected).origin) return NextResponse.json({error:'Origem inválida.'},{status:403});
  if(!request.headers.get('content-type')?.startsWith('application/json')) return NextResponse.json({error:'Formato inválido.'},{status:415});
  try {
    const reader=request.body?.getReader();if(!reader) throw new Error('RVP_BODY');
    const chunks:Uint8Array[]=[];let size=0;
    for(;;){const {done,value}=await reader.read();if(done) break;size+=value.byteLength;if(size>64000){await reader.cancel();return NextResponse.json({error:'Formulário muito grande.'},{status:413});}chunks.push(value);}
    let parsed;try {parsed=validateSubmission(JSON.parse(Buffer.concat(chunks).toString('utf8')));}catch {return NextResponse.json({error:'Confira o nome, a data e as 70 respostas.'},{status:400});}
    const rate=await consumeRateLimit('rvp-submit',parsed.id,5,3600);
    if(!rate.allowed) return NextResponse.json({error:'Aguarde antes de reenviar.'},{status:429});
    const result=await saveSubmission(parsed);
    after(async()=>{try {await notifyPending();}catch {console.error('RVP_NOTIFICATION_WORKER_FAILED');}});
    return NextResponse.json({...result,saved:true},{status:result.repeated?200:201,headers:{'Cache-Control':'no-store'}});
  } catch(e) {
    if(e instanceof Error && e.message==='RVP_CONFLICT') return NextResponse.json({error:'Este envio já foi utilizado com outros dados.'},{status:409});
    return NextResponse.json({error:'Não foi possível salvar. Suas respostas continuam neste navegador; tente novamente.'},{status:503});
  }
}
