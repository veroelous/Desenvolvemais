import mysql, { type RowDataPacket } from 'mysql2/promise';
import { randomUUID } from 'node:crypto';
import { assertExpectedDatabase } from '@/lib/db/config';
import { createSmtpMailer } from '@/lib/auth/mail';

const recipient = 'contato@manoelgoncalves.com';
let pool: mysql.Pool | undefined;
function connection() { return pool ??= mysql.createPool({ ...assertExpectedDatabase(), connectionLimit: 3, timezone: 'Z' }); }
export const schema = [
  `CREATE TABLE IF NOT EXISTS rvp_assessments (id CHAR(36) CHARACTER SET ascii PRIMARY KEY,payload_hash CHAR(64) CHARACTER SET ascii NOT NULL,payload_json JSON NOT NULL,averages_json JSON NOT NULL,completed_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)) ENGINE=InnoDB`,
  `CREATE TABLE IF NOT EXISTS rvp_notifications (assessment_id CHAR(36) CHARACTER SET ascii PRIMARY KEY,recipient VARCHAR(254) NOT NULL,state VARCHAR(16) NOT NULL DEFAULT 'pending',attempts INT NOT NULL DEFAULT 0,next_attempt DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),lease_id CHAR(36) NULL,lease_until DATETIME(3) NULL,sent_at DATETIME(3) NULL,INDEX rvp_due (state,next_attempt),FOREIGN KEY (assessment_id) REFERENCES rvp_assessments(id)) ENGINE=InnoDB`
];
let ready: Promise<void> | undefined;
export function ensureSchema() { return ready ??= (async()=>{ for(const statement of schema) await connection().query(statement); })().catch(e=>{ ready=undefined; throw e; }); }
export async function saveSubmission(value: {id:string;hash:string;payload:unknown;averages:number[]}) {
  await ensureSchema();
  const c = await connection().getConnection();
  try {
    await c.beginTransaction();
    let repeated = false;
    try { await c.execute('INSERT INTO rvp_assessments(id,payload_hash,payload_json,averages_json) VALUES(?,?,?,?)', [value.id,value.hash,JSON.stringify(value.payload),JSON.stringify(value.averages)]); }
    catch(e) { if((e as {code?:string}).code !== 'ER_DUP_ENTRY') throw e; repeated=true; }
    const [rows] = await c.execute<RowDataPacket[]>('SELECT payload_hash FROM rvp_assessments WHERE id=? FOR UPDATE',[value.id]);
    if(rows[0]?.payload_hash !== value.hash) throw new Error('RVP_CONFLICT');
    if(!repeated) await c.execute('INSERT INTO rvp_notifications(assessment_id,recipient) VALUES(?,?)',[value.id,recipient]);
    await c.commit();
    return {id:value.id,repeated};
  } catch(e) { await c.rollback(); throw e; } finally { c.release(); }
}
export async function notifyPending() {
  await ensureSchema();
  const db=connection();
  const [rows]=await db.execute<RowDataPacket[]>(`SELECT n.assessment_id,n.recipient,a.payload_json,a.completed_at FROM rvp_notifications n JOIN rvp_assessments a ON a.id=n.assessment_id WHERE n.state<>'sent' AND n.next_attempt<=UTC_TIMESTAMP(3) AND (n.lease_until IS NULL OR n.lease_until<UTC_TIMESTAMP(3)) ORDER BY n.next_attempt LIMIT 5`);
  for(const row of rows) {
    const lease=randomUUID();
    const [result]=await db.execute<mysql.ResultSetHeader>(`UPDATE rvp_notifications SET lease_id=?,lease_until=DATE_ADD(UTC_TIMESTAMP(3),INTERVAL 2 MINUTE),attempts=attempts+1 WHERE assessment_id=? AND state<>'sent' AND (lease_until IS NULL OR lease_until<UTC_TIMESTAMP(3))`,[lease,row.assessment_id]);
    if(!result.affectedRows) continue;
    try {
      const data=typeof row.payload_json==='string'?JSON.parse(row.payload_json):row.payload_json;
      await createSmtpMailer().send({to:row.recipient,subject:`Roda da Vida concluída — ${data.profile.name}`,text:`Uma avaliação da Roda da Vida foi concluída e salva.\n\nRespondente: ${data.profile.name}\nEmpresa: ${data.profile.company || 'Não informada'}\nFunção: ${data.profile.role || 'Não informada'}\nIdentificador: ${row.assessment_id}\nData da avaliação: ${data.profile.date}\n\nAs respostas e as 14 médias estão registradas no banco do sistema. Este aviso não contém respostas pessoais.`});
      await db.execute(`UPDATE rvp_notifications SET state='sent',sent_at=UTC_TIMESTAMP(3),lease_until=NULL,lease_id=NULL WHERE assessment_id=? AND lease_id=?`,[row.assessment_id,lease]);
    } catch {
      await db.execute(`UPDATE rvp_notifications SET lease_until=NULL,lease_id=NULL,next_attempt=DATE_ADD(UTC_TIMESTAMP(3),INTERVAL 5 MINUTE) WHERE assessment_id=? AND lease_id=?`,[row.assessment_id,lease]);
      console.error('RVP_NOTIFICATION_PENDING',row.assessment_id);
    }
  }
}
